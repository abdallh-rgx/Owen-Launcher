#!/usr/bin/env python3
"""Identify a Fortnite CloudDir manifest: download <HASH>.manifest and read its BuildVersion.
Epic .manifest format: 41-byte header (magic 0x44bec00c, sizes, SHA1, version), zlib body,
body starts: DataVersion u32, ?, ?, then FString AppName @14, FString BuildVersion.
Usage: python3 identify_manifest.py HASH1 [HASH2 ...]
"""
import sys, zlib, struct, urllib.request

CDN = "https://epicgames-download1.akamaized.net/Builds/Fortnite/Content/CloudDir/"

def identify(h):
    data = urllib.request.urlopen(CDN + h + ".manifest", timeout=60).read()
    inner = zlib.decompressobj().decompress(data[41:])
    def lstr(off):
        n = struct.unpack_from("<I", inner, off)[0]
        return inner[off+4:off+4+n-1].decode(errors="replace"), off+4+n
    app, off = lstr(14)
    build, off = lstr(off)
    return len(data), app, build

if __name__ == "__main__":
    for h in sys.argv[1:]:
        size, app, build = identify(h)
        print(f"{h:35s} {size:>8d}B  {app}  {build}")
