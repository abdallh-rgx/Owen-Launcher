# Fortnite Android — Manifest Hash Database (CloudDir)

> **الهدف الأصلي:** إيجاد manifest hash لإصدار 12.41 — تم بنجاح ✅
> **الطريقة:** سلسلة الدلتا على CDN الإبيك (Delta-Chain Discovery) — انظر الأسفل.

## 🎯 النتيجة المطلوبة

| الإصدار | CL | Manifest Hash | APK المطابق |
|---------|-----|---------------|-------------|
| **12.41** | **12910313** | **`aEzFZyiSFDrqiS_7jkqD6K8KN4zQEg`** | fortnite-12-41-0-12910313-android.apk ✅ |
| 12.41 (hotfix) | 12948829 | `qEuvqZqHRP9IipPXDUK-c7g2-oa6Zg` | بيلد لاحق من نفس الموسم |

## 📦 روابط CDN المباشرة (تعمل الآن — مُختبرة HTTP 200)

```
https://epicgames-download1.akamaized.net/Builds/Fortnite/Content/CloudDir/aEzFZyiSFDrqiS_7jkqD6K8KN4zQEg.manifest
https://epicgames-download1.akamaized.net/Builds/Fortnite/Content/CloudDir/aEzFZyiSFDrqiS_7jkqD6K8KN4zQEg/BackgroundDownloads.ini
https://epicgames-download1.akamaized.net/Builds/Fortnite/Content/CloudDir/aEzFZyiSFDrqiS_7jkqD6K8KN4zQEg/Full.ini
https://epicgames-download1.akamaized.net/Builds/Fortnite/Content/CloudDir/ChunkDbs/aEzFZyiSFDrqiS_7jkqD6K8KN4zQEg_FortniteBR.part01.chunkdb  (وكل الأجزاء)
```

**تنسيق عام لأي إصدار (مُكتشف حديثاً):**
```
https://epicgames-download1.akamaized.net/Builds/Fortnite/Content/CloudDir/<HASH>.manifest
https://epicgames-download1.akamaized.net/Builds/Fortnite/Content/CloudDir/<HASH>/BackgroundDownloads.ini
https://epicgames-download1.akamaized.net/Builds/Fortnite/Content/CloudDir/<HASH>/Full.ini
```

## 🗃️ قاعدة البيانات الكاملة (كل ما تم اكتشافه والتحقق منه من CDN مباشرة)

| BuildVersion | Manifest Hash |
|---|---|
| ++Fortnite+Release-11.31-CL-10853343-Android | `q25EmP_XlhCdbRc1Kka6ZLaUwzSDuw` |
| ++Fortnite+Release-11.40-CL-10948180-Android | `eMHfwvzx6ilSW-S32UGQ_UiuvG3Vtg` |
| ++Fortnite+Release-11.40-CL-10993225-Android | `oQ2iSEtsGXzpgpzQu0efGmRygMHvEQ` |
| ++Fortnite+Release-11.40-CL-11112758-Android | `fRx6cCBiOjGfNVpCO0S3mdKdkCt9RA` |
| ++Fortnite+Release-11.50-CL-11204868-Android | `dBLCJG_9Fga8dhu5XUSTajhn4el_hQ` |
| ++Fortnite+Release-11.50-CL-11265652-Android | `h4jFrR-41gvk3BXN80y5BPquJa1A0A` |
| ++Fortnite+Release-12.00-CL-11529743-Android | `_91WxyXFMQZAeQ93lESx44GYhhAaUQ` |
| ++Fortnite+Release-12.00-CL-11573981-Android | `ZDpFkNbWz_7dWPZqYU2ERg0pivspww` |
| ++Fortnite+Release-12.00-CL-11573981-CP11714580-Android | `D_hcnoUhpY45CHcNNE6sKd6iBtIWww` |
| ++Fortnite+Release-12.10-CL-11794982-Android | `8wUBatavCLAjSi3arkGbL5_prhLd0g` |
| ++Fortnite+Release-12.21-CL-12395074-Android | `qLsdJyXRD_zotj3DX0KNuMGRWS7etw` |
| ++Fortnite+Release-12.30-CL-12486755-Android | `ggWwml6bEICZBlrGPUuHsfs1J3zplg` |
| ++Fortnite+Release-12.30-CL-12502623-Android | `pQg1ACifcbd-yGe5zkWSZYKJUVzBLA` |
| ++Fortnite+Release-12.30-CL-12624643-Android | `rPPWEHcWA8eYpC3XxEybSa7tyJ9y6A` |
| ++Fortnite+Release-12.40-CL-12743641-Android | `OCs49CEcVD2Dm5lXhUSzwlF5kPl2hA` |
| ++Fortnite+Release-12.40-CL-12837456-Android | `9Zd_VZAmfDyKWe2qwEWZL7O8wcK0Qg` |
| **++Fortnite+Release-12.41-CL-12910313-Android** | **`aEzFZyiSFDrqiS_7jkqD6K8KN4zQEg`** ⭐ |
| ++Fortnite+Release-12.41-CL-12948829-Android | `qEuvqZqHRP9IipPXDUK-c7g2-oa6Zg` |
| ++Fortnite+Release-12.50-CL-13044369-Android | `vIgppZezObOg6d1GwUu5ryTXkkdEJA` |
| ++Fortnite+Release-12.50-CL-13044691-Android | `e_ZEF-BdEBHy-2pub0aC_NKUfYs2-A` (APK 12.50 الموجود عندنا) |
| ++Fortnite+Release-12.50-CL-13070868-Android | `8iHlkg8Bd7cAGiv8hUSHyiTamMLtQQ` |
| ++Fortnite+Release-12.50-CL-13070927-Android | `87Pe9zdOHDli9ZqYC06U-P24DurVeA` |
| ++Fortnite+Release-12.50-CL-13145792-Android | `j5mFM96__zfBiAX23E2vS7zDPkonoQ` |
| ++Fortnite+Release-12.50-CL-13145792-CP13294732-Android | `8sn__wuGlK6j0zeWNUyMQ-svf5TvXQ` |
| ++Fortnite+Release-12.50-CL-13179981-Android | `-04l9M68rnQuyTXf6Uud9qEls6DrZQ` |
| ++Fortnite+Release-12.50-CL-13179981-CP13294732-Android | `ThY3xhZ8cBjovxgDDk6lDmlrnn5T0w` |
| ++Fortnite+Release-12.50-CL-13294732-Android | `NK5d3mcay7e_fqcyQ06rmEjFVHX1gQ` |
| ++Fortnite+Release-12.60-CL-13315662-Android | `7loAvkN0gInoJ3BmIUqKkS-sJ4jQCA` |
| ++Fortnite+Release-12.60-CL-13333624-Android | `CW6o5EyZwctpgqz35UC-qEybjwqaAw` |
| ++Fortnite+Release-12.61-CL-13498347-Android | `mSs7lzt6QOVv6SKlOE21TcBvJU4lnw` |
| ++Fortnite+Release-12.61-CL-13498980-Android | `5UR0XFTlmPSJlqpGpE60LF1pmp5OjQ` |
| ++Fortnite+Release-13.00-CL-13649278-Android | `u-oTvtm5PVAMd8kwGkqjQTEDjk4gEw` |
| ++Fortnite+Release-13.00-CL-13649811-Android | `fbL9Hp5RcLbfBSuFXU6d0t0HtCDNlg` |
| ++Fortnite+Release-13.00-CL-13715544-Android | `DOKYY-S3KyDzjJyLOUqv2TuCUbQTYw` |
| ++Fortnite+Release-13.00-CL-13715664-Android | `w80l2cYc6XImANM1iE6y1pcmrj71jA` |
| ++Fortnite+Release-13.20-CL-13777676-Android | `LbsMhzBedtbqm1XN1UKUkaJNIrP6LA` |
| ++Fortnite+Release-13.20-CL-13778048-Android | `Te2GcsNotd6-wgYkm0-_d9SkX6vRqA` |
| ++Fortnite+Release-13.30-CL-13880136-Android | `llSjZLhgxom9EL6_sEis-Q9f35bLSQ` |

## 🔬 كيف تم الإكتشاف (Delta-Chain Discovery)

**المشكلة:** 12.41 مخفي تماماً — غير موجود في أي APK (ملف `assets/Cloud/BuildInfo.ini` يحتوي فقط `Build` + `Label`)، وقاعدة بيانات المجتمع (asset_info) تقفز من 12.10 إلى 12.50، وواجهة Epic للـ OAuth تحجب طلبات الـ datacenter IPs (404).

**الحل — 4 خطوات:**

1. **فهم البنية:** APK 11.31 يحتوي `assets/Cloud/BackgroundDownloads.ini` صراحةً بالهاش (لهذا كان سهلاً). إصدارات 12.41+ حذفته من الـ APK.
2. **اكتشاف نمط URL الـ ini على CDN بالتجربة:**
   `CloudDir/<manifestHash>/BackgroundDownloads.ini` + `CloudDir/<manifestHash>/Full.ini` (HTTP 200)
3. **سلسلة الدلتا:** ملف `BackgroundDownloads.ini` لأي بيلد يحتوي أقسام دلتا بالشكل:
   `[<الهاش-الحالي>.manifest-<هاش-الإصدار-الأقدم>.manifest,Tag]`
   فبدأنا من هاشات 12.61 المعروفة → كشفنا 11 هاشاً مجهولاً → تبين أنها 12.50/12.60 → نزّلنا ملفات الـ ini الخاصة بها → كشفت 8 هاشات مجهولة أخرى → هي 12.21/12.30/12.40/**12.41**!
4. **التحقق:** تنزيل كل مرشح من `CloudDir/<hash>.manifest` وفك ضغط zlib ثم قراءة FString الـ BuildVersion (بُنيت أداة بايثون لهذا — `/tmp/final_id2.py` ومسارها النهائي `fn1241/tools/identify_manifest.py`).

**التحقق النهائي لـ 12.41:** الملف `aEzFZyiSFDrqiS_7jkqD6K8KN4zQEg.manifest` (547,666 بايت) يحتوي داخلياً:
```
AppName      = FortniteContentBuilds
BuildVersion = ++Fortnite+Release-12.41-CL-12910313-Android   ← مطابق تماماً لاسم الـ APK
```

## ⚙️ تطبيقها في Voltronite (تم التعديل)

1. `src/routes/data.ts` السطر 69:
   ```ts
   path: "Builds/Fortnite/Content/CloudDir/aEzFZyiSFDrqiS_7jkqD6K8KN4zQEg.manifest",
   ```
2. ملفات `public/clouddir/` استُبدلت بالحزمة الحقيقية:
   - `manifest.manifest` = ملف 12.41 الحقيقي (547KB)
   - `Full.ini` = Full.ini الخاص بـ 12.41 (16.7KB)
   - `BackgroundDownloads.ini` = الخاص بـ 12.41 (77.5KB) — **جديد**
3. **مسارات جديدة** في data.ts تطابق طلبات العميل الحقيقي (مستخرجة من libUE4.so — InstallBundleSourceBPS):
   - `GET /Builds/Fortnite/Content/CloudDir/:hash/BackgroundDownloads.ini`
   - `GET /Builds/Fortnite/Content/CloudDir/:hash/Full.ini`
   - (المسار القديم `/CloudDir/manifest/:file.ini` أُبقي للتوافق)
4. إصلاح خطأ قديم: مسار الـ chunk كان يقرأ `manifest.chunk` غير الموجود → أصبح `chunk.chunk`.

## 🔁 لتكرار العملية على أي إصدار آخر (auto manifest redirector)

```bash
# 1) خذ هاش إصدار معروف (من ini أو APK قديم ≤11.31)
# 2) نزّل ini الخاص به:
curl https://epicgames-download1.akamaized.net/Builds/Fortnite/Content/CloudDir/<HASH>/BackgroundDownloads.ini
# 3) استخرج كل الأقسام [<cur>-<src>.manifest,...] → هاشات الإصدارات الأقدم
# 4) كرر بشكل تكراري (كل هاش جديد يفتح هاشات أقدم)
# 5) حدّد هوية كل هاش: نزّل <HASH>.manifest واقرأ BuildVersion (zlib بعد البايت 41، FString عند offset 14)
```

**أدوات جاهزة:** `/home/z/fn1241/tools/identify_manifest.py` و `/home/z/fn1241/tools/delta_chain.py`
