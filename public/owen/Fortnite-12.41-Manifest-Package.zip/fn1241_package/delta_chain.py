#!/usr/bin/env python3
"""Delta-chain discovery: every build's BackgroundDownloads.ini lists older manifests it can
delta-update from: [<cur>.manifest-<old>.manifest,Tag]. Walk the chain to discover unknown hashes.
Usage: python3 delta_chain.py KNOWN_HASH1 [KNOWN_HASH2 ...]
"""
import re, sys, urllib.request

CDN = "https://epicgames-download1.akamaized.net/Builds/Fortnite/Content/CloudDir/"

def sources(h):
    url = CDN + h + "/BackgroundDownloads.ini"
    try:
        data = urllib.request.urlopen(url, timeout=60).read().decode(errors="replace")
    except Exception as e:
        print(f"  (no ini for {h}: {e})")
        return set()
    return {m.group(2) for m in re.finditer(r'\[([A-Za-z0-9_-]+)\.manifest-([A-Za-z0-9_-]+)\.manifest,', data)}

if __name__ == "__main__":
    known = set(sys.argv[1:])
    seen = set()
    frontier = set(known)
    while frontier:
        h = frontier.pop()
        if h in seen: continue
        seen.add(h)
        srcs = sources(h)
        new = {s for s in srcs if s not in known and s not in seen}
        print(f"{h}: {len(srcs)} delta sources ({len(new)} new)")
        for s in sorted(new): print(f"   NEW: {s}")
        frontier |= new
    print("\nAll discovered hashes:")
    for h in sorted(seen): print("  ", h)
